
<!DOCTYPE html>
<html lang="en">

<head>
   <meta charset="UTF-8">
   <meta http-equiv="X-UA-Compatible" content="IE=edge">
   <meta name="viewport" content="width=device-width, initial-scale=1.0">
   <title>QR Code Page</title>
   <!-- Tambahkan stylesheet atau gaya CSS sesuai kebutuhan -->
   <style>
      body {
         text-align: center;
      }

      img {
         max-width: 100%;
         height: auto;
      }

      button {
         background-color: brown;
         color: white;
         padding: 10px 20px;
         border: none;
         cursor: pointer;
         font-size: 16px;
         margin-top: 20px;
      }
   </style>
</head>

<body>
   <img src="images/Danawidhi.jpg" alt="Dana QR Code">
   <br>
   <a href="home.php"><button>Selesai Membayar</button></a>
   <!-- Tambahkan elemen atau tautan lainnya sesuai kebutuhan -->
   
</body>
</html>

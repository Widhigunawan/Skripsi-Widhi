<footer class="footer">

   <section class="box-container">

      <div class="box">
         <h3>Tautan Langsung</h3>
         <a href="home.php"> <i class="fas fa-angle-right"></i> Beranda</a>
         <a href="shop.php"> <i class="fas fa-angle-right"></i> Belanja</a>
         <a href="about.php"> <i class="fas fa-angle-right"></i> Tentang Kami</a>
         
      </div>

      <div class="box">
         <h3>Tautan Ekstra</h3>
         <a href="cart.php"> <i class="fas fa-angle-right"></i> Keranjang</a>
         <a href="wishlist.php"> <i class="fas fa-angle-right"></i> Daftar keinginan</a> 
      </div>

      <div class="box">
         <h3>Kontak</h3>
         <p> <i class="fas fa-phone"></i>0895333541781 </p>
         <p> <i class="fas fa-envelope"></i> widhiGunawan7@gmail.com </p>
         <p> <i class="fas fa-map-marker-alt"></i> Cileungsi, Bogor - 16820 </p>
      </div>


   </section>

   <!-- <p class="credit"> &copy; copyright @ <?= date('Y'); ?> by <span>Widhi Present</span> | all rights reserved! </p> -->

</footer>